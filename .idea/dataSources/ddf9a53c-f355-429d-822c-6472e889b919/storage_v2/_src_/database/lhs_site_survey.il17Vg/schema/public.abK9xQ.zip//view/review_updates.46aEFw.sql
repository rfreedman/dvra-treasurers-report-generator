create view review_updates(id, property_id, username, event_type, event_date) as
SELECT id,
       property_id,
       username,
       event_type,
       event_date
FROM review_events re
WHERE event_type::text = 'update'::text;

alter table review_updates
    owner to rfreedman;

