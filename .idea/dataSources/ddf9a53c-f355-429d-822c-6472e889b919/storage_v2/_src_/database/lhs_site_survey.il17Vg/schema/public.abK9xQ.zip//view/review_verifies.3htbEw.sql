create view review_verifies(id, property_id, username, event_type, event_date) as
SELECT id,
       property_id,
       username,
       event_type,
       event_date
FROM review_events
WHERE event_type::text = 'update'::text;

alter table review_verifies
    owner to rfreedman;

