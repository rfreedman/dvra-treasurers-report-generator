create view street_names(id, street_name) as
SELECT DISTINCT street_name                AS id,
                initcap(street_name::text) AS street_name
FROM property p
WHERE street_name IS NOT NULL
ORDER BY street_name;

alter table street_names
    owner to rfreedman;

