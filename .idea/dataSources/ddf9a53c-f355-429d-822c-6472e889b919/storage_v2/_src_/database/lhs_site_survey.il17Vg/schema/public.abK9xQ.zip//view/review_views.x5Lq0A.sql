create view review_views(id, property_id, username, event_type, event_date) as
SELECT id,
       property_id,
       username,
       event_type,
       event_date
FROM review_events
WHERE event_type::text = 'view'::text;

alter table review_views
    owner to rfreedman;

